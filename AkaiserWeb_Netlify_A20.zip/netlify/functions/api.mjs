import { getStore } from '@netlify/blobs';
import { createHandler } from '../../src/core.mjs';

// Netlify Blobs = the database. "strong" consistency so a code typed on the site is seen by the app at once.
const handler = createHandler(() => getStore({ name: 'akaiser', consistency: 'strong' }), {
  maxDevices: parseInt(process.env.MAX_DEVICES || '5', 10),
});

export default (req, context) => handler(req, context);

export const config = { path: '/api/*' };
