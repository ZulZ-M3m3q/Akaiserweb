# AkaiserEvodroid account website - Netlify version

Same website and same app API as the Render/Docker version, but runs on Netlify's free plan:
pages in `public/`, the API in one Netlify Function (`netlify/functions/api.mjs`), data in Netlify Blobs.

## Deploy (GitHub method - the one that works for sure)
1. Create a GitHub repo and upload the CONTENTS of this folder (so `netlify.toml` is in the repo root).
2. Netlify -> Add new site -> Import an existing project -> pick the repo. Leave every build setting empty
   (netlify.toml already has them). Deploy.
3. Open `https://YOUR-SITE.netlify.app` in a browser: you should see the sign-up page.
4. Check the API (from a PC):
   `curl -i -X POST https://YOUR-SITE.netlify.app/api/device/status -H "Authorization: Device aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" -H "Content-Type: application/json" -d "{}"`
   It must answer `200` and `{"linked":false,"code":"XXXX-XXXX",...}`.
5. Build the APK (A.17 workflow) with `web_url` = `https://YOUR-SITE.netlify.app` (no slash at the end).

Dragging the folder into Netlify "Deploy manually" may skip installing the function's dependency; use GitHub
(or the Netlify CLI: `npm i -g netlify-cli && netlify deploy --prod`).

## Test on your PC (no network, no Netlify needed)
    node test.mjs        # 68 automatic checks against an in-memory fake of Netlify Blobs

## Settings (Netlify -> Site configuration -> Environment variables)
| name | default | meaning |
|---|---|---|
| `MAX_DEVICES` | 5 | phones one account may link |

## Play time (A.20)
The app reports each finished play session to `POST /api/device/playtime`; the dashboard shows total, last 7 days,
a 14-day chart and recent sessions. Data is in Blobs key `p:<username>` (totals + newest 200 sessions).

## Owner tools
No `admin.js` here. Forgotten passwords: delete the user in Netlify -> Blobs -> `akaiser` store -> key `u:<username in lowercase>`
(the player can then sign up again with the same name).

## Differences from the Docker version
- Data is in Netlify Blobs instead of SQLite. Back it up by copying the `akaiser` store if you care.
- The per-IP "120 polls per minute" limit on `/api/device/status` was dropped (it would cost a Blobs write per poll).
  New-device, login, sign-up and link-code limits are kept.
- Two requests at the exact same moment on the same account can overwrite each other (no database transactions).
  Fine for a small number of players.
